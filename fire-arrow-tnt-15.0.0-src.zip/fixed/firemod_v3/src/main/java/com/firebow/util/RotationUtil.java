package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation — server thấy đúng, camera không giật.
 * Học từ BOOST-FPS applyRotation pattern.
 * Grim kiểm tra hit vector phải khớp look direction.
 */
public final class RotationUtil {
    private RotationUtil() {}

    /**
     * Tính yaw/pitch để nhìn vào target.
     */
    public static float[] calcRotation(ClientPlayerEntity player, Vec3d target) {
        Vec3d eyes = player.getEyePos();
        double dx = target.x - eyes.x;
        double dy = target.y - eyes.y;
        double dz = target.z - eyes.z;
        double dist = Math.sqrt(dx*dx + dz*dz);

        float yaw   = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    /**
     * Apply rotation lên server side only.
     * Camera không di chuyển — chỉ update lastBodyYaw/lastHeadYaw.
     */
    public static void applySilent(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw    = rot[0];
        player.bodyYaw    = rot[0];
    }

    public static void restoreRotation(ClientPlayerEntity player, float yaw, float pitch) {
        player.setYaw(yaw);
        player.setPitch(pitch);
        player.headYaw = yaw;
        player.bodyYaw = yaw;
    }

    /** Hit vector plausible từ góc nhìn hiện tại vào face của block. */
    public static Vec3d calcHitVec(ClientPlayerEntity player, Vec3d blockCenter,
                                    net.minecraft.util.math.Direction face) {
        // Điểm chạm = center của block face được nhìn vào
        Vec3d faceCenter = blockCenter.add(
            face.getOffsetX() * 0.5,
            face.getOffsetY() * 0.5,
            face.getOffsetZ() * 0.5
        );
        // Thêm slight offset từ center để trông natural hơn
        return faceCenter;
    }

    public static boolean inReach(ClientPlayerEntity player, net.minecraft.util.math.BlockPos pos) {
        Vec3d center = Vec3d.ofCenter(pos);
        return player.getEyePos().squaredDistanceTo(center) <= 4.5 * 4.5;
    }
}
