package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v2 — rotation-based placement.
 * Grim kiểm tra hit vector khớp look direction.
 * Học từ BOOST-FPS runWithInteractionRotation.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    /**
     * Đặt rail: rotate nhìn vào top face của block dưới railPos,
     * interact, restore rotation.
     */
    public static boolean placeBelow(MinecraftClient mc, BlockPos railPos) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;

        BlockPos target = railPos.down();
        Vec3d hitVec = Vec3d.ofCenter(target).add(0, 0.5, 0);

        // Rotate toward target
        float savedYaw = p.getYaw(), savedPitch = p.getPitch();
        float[] rot = RotationUtil.calcRotation(p, hitVec);
        RotationUtil.applySilent(p, rot);

        try {
            p.swingHand(Hand.MAIN_HAND);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                new BlockHitResult(hitVec, Direction.UP, target, false));
            return true;
        } finally {
            RotationUtil.restoreRotation(p, savedYaw, savedPitch);
        }
    }

    /**
     * Đặt cart lên rail tại railPos.
     */
    public static boolean placeOnTop(MinecraftClient mc, BlockPos railPos) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;

        Vec3d hitVec = Vec3d.ofCenter(railPos).add(0, 0.1, 0);

        float savedYaw = p.getYaw(), savedPitch = p.getPitch();
        float[] rot = RotationUtil.calcRotation(p, hitVec);
        RotationUtil.applySilent(p, rot);

        try {
            p.swingHand(Hand.MAIN_HAND);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                new BlockHitResult(hitVec, Direction.UP, railPos, false));
            return true;
        } finally {
            RotationUtil.restoreRotation(p, savedYaw, savedPitch);
        }
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
